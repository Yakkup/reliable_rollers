package com.example.reliable_rollers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReliableRollersApplicationTests {

	@Test
	void contextLoads() {
	}

}
