package com.example.reliable_rollers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReliableRollersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReliableRollersApplication.class, args);
	}

}
