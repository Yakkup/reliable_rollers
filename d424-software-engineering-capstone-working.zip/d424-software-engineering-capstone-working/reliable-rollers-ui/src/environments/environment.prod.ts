export const environment = {
  production: true,
  apiUrl: 'http://3.138.193.91:8080/api'
};
